public class Matrix extends Thread { 

    private static int [][] a; 
    private static int [][] b; 
    private static int [][] c; //Variable which hold the answer

    /* You might need other variables as well */
    private int myColumnA;
    private int myRowB;
    private int threadID;

    public Matrix(int colA,int rowB,int thr) { // need to change this, might need some information
    this.myColumnA = colA;                       //variable which holds number of elements in a row(ie: number of columns of Matrix A) of first operand(Matrix A)
    this.myRowB = rowB;                       //variable which holds number of elements in a column(ie: number of rows of Matrix B) in operand 2(Matrix B)
    this.threadID = thr;                      //variable to identify which thread(rows of Matrix A are divided according to the threadID given to each thread)
    }
   
    /* the allocated work to each thread :- multiply a particular row from operand 1 with all the columns 
                                            in operand 2 and store the value in the respective spot of matrix "c"     */
    public void run(){                            
        for(int k = 0;k<this.myRowB;k++){       //for loop to iterate over nuber of elements in a row in operand1
        	int s=0;
        	for(int i = 0;i<this.myColumnA;i++){                    //for loop to multiply each value in the row of 1st operand with the respective value in 2nd operand and adding together
                s += Matrix.a[this.threadID][i]*Matrix.b[i][k];
            }
            Matrix.c[this.threadID][k]=s;                              // store calculated value in matrix c
        }
        
    } 

    public static int [][] multiply(int [][] a, int [][] b) {

	/* check if multipication can be done, if not 
	 * return null 
	 * allocate required memory 
	 * return a * b
	 */
    Matrix.a = a;
    Matrix.b = b;
    

	int x = a.length;      //i am going to create this much of threads
	int y = b[0].length; 

	int [][] result = new int [x][y];
    Matrix.c = result;

	int z1 = a[0].length; 
	int z2 = b.length; 

	if(z1 != z2) { 
	    System.out.println("Cannnot multiply");
	    return null;
	}

	Matrix [] threads = new Matrix[x]; 
	
	for(int i=0; i < x; i++) {           //creating no of threads equels to the no of rows in 1st operand matrix 
	    threads[i] = new Matrix(z1,y,i);    //here i considered multiplying each row of operand 1 with all the columns in operand 2 is allocated to a particular thread
	    threads[i].start();                 //parallalized multiplication of each row with all of the columns in operand 2
	}

	for(int i=0; i < x; i++) { 
	    try { 
		threads[i].join();                   //wait until all threads finish
	    } catch (InterruptedException e) { 
		System.out.println("Problem Occured");
	    }
	}
	    

	return result;         // after all threads are done with their job return
    }

}


/*

1).Operation parallized to threads by dividing 1st operand into its rows and do the multiplication as just one row matrix with the 
   other whole matrix

2).Each row was allocated to a one particular thread

3).Using run method each thread was allocated to multiply the given row with the matrix (2nd operand) and store it in a temporary matrix 
  until finally assigned to Result Matrix

4).This whole threads are independently operate until synchronized in last for loop resulting to be wait until whole threads get the job done   

*/ 