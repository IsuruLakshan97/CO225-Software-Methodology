
/* my array list: an array that behaves like a list 
 * E/16/203
 */

public class MySet<T/* Can we have any T */> { 

    int nextItem; 
    int currentCapacity; 
    T[] data; // DO NOT CHANGE

    private static int defaultSizeToCreate = 10; // how many elements to create 

    @SuppressWarnings("unchecked")
    public MySet(int elements) { 
	this.nextItem = 0; 
	this.defaultSizeToCreate = elements; 
	this.currentCapacity = elements; 

	this.data = (T[]) new Object[this.defaultSizeToCreate]; 
    }

    public MySet() { 
	this(defaultSizeToCreate); 
    }

    public boolean isEmpty() { return this.nextItem == 0; } 
    public boolean isFull() { return false; /* never get filled */} 

    public boolean add(T item) { 

	/* if there is any element delete it 
	 * then add the new element. 
	 * How do you handle when the array is full: 
	 * crate a new array with currentCapacity+defaultSizeToCreate, 
	 * copy the old conents into that
	 * Accessing array when full might be a problem
	 */
	try{
		        data[nextItem] = null; // DO NOT CHANGE 
				int i =0;
				while(data[i]!=null){            //loop to check wether theres a match in input and an element already in the array
					if(data[i].equals(item)){
			           return false;
					}
					i++;
				}
			    data[i]=item;                   //if there isnt a match add the input to end of the array
			    nextItem=i+1;                   //point the nextItem to the next index of the array
			    return true;                    //return
    }
    catch (Exception e){                        //if there is index out of bound exception catch it
    	         this.currentCapacity=this.currentCapacity+this.defaultSizeToCreate;         //update the default size
    	         T[] temp = (T[]) new Object[this.currentCapacity];                          //create a new array which has updated number of elements
    	         int x =0; 
    	         while(x<data.length){             //copy the elements that is in the data array to the new array
    	         	temp[x]=data[x];
    	         	x++;
    	         }
    	         data = temp;                     

                int i =0;                        //loop to check wether theres a match in input and an element already in the array             
				while(data[i]!=null){
					if(data[i].equals(item)){
			           return false;
					}
					i++;
				}

			    data[nextItem]=item;
			    nextItem++;
			    return true;
    }
	/* Add the item to the array if the item is not there */
	//return true; // CHANGE ME

    }


    public T remove() { 
	/* remove the first element in the array 
	 * and copy the rest front. 
	 * FIFO structure. 
	 * If the ArrayList is empty return null
	 */


	/* Option 1: */
	if(isEmpty()) return null; 
	// IMPLEMENT THE REST 
    T element = data[0];
    int k = 0;
    while(k+1<nextItem){
    	data[k]=data[k+1];
    	k++;
    }
    nextItem--;
    data[nextItem]=null;          //setting the last element to null
    return element;


																					// /* Option 2: */
																					// if(!isEmpty()) { 
																					//     // IMPLEMENT THE REST
																					//     T element = data[0];
																					//     int k = 0;
																					//     while(k+1<nextItem){
																					//     	data[k]=data[k+1];
																					//     	k++;
																					//     }
																					//     nextItem--;
																					//     return element;
																					// }
																					// return null;                           


	// which option is better? why?    **answered in answer.txt
    }


}
	 

	