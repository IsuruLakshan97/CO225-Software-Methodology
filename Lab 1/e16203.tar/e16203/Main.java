package lab_01;
import java.io.*; // for file IO


public class Main {
	public static void main(String [] args) {
		/**************************************************************/ 
		/* Reading a file and adding it into a array named as "names" */
		BufferedReader descriptor = null; 
		//String line = null; 
		String [] names = new String[62]; // 61 names 
		try { 
		    descriptor = new BufferedReader(
				    new FileReader("co225-classlist.txt"));

		    for(int i=0; i < names.length; i++) // assume file has 61 lines 
			names[i] = descriptor.readLine(); 

		    descriptor.close(); 

		} catch(IOException e) { 
		    // IOException is more generic (FileNotFound is a type of a 
		    // IOException, so catching only that is sufficient 
		    System.out.println("Bad things happen, what do you do!" + e);
		    return; 
		}
		
		Student Student_1 = new Student();  
		for(int i =0;i<names.length-1;i++) {  //getting inputs in the array of names one by one and give it to the student class print the name if the attendance is lower than 80%
			Student_1.setName(names[i]);
			int rand = (int)(Math.random() * 45); //creating random integer between 0 and 45
			Student_1.setAttendance(rand);     //giving that random number as attendance to the student class through setAttendance method
			if(Student_1.getAverageAttendance()<80) {
				  System.out.println(Student_1.getName());
			}
		}
        
		//System.out.println(Student_1.getTotalAttendance() + "%");    //to get total average percentage attendance 
	}
   
}
