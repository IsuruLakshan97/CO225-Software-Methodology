package lab_01;
class Student{
	//attributes
	public String Name;
	public float attendance;
	public int totalAttendance=0;
	public int NoStudents=0;
	public float attendance1;
	
	public void setName(String Name) { //method to get the name
		this.Name = Name;
	}
	
	public void setAttendance(int attendance) { //method to get the attendance and total number of students
		this.attendance = attendance;
		totalAttendance += attendance;
		NoStudents += 1;
	}
	
	public float getAverageAttendance(){   //method to get the average attendance of each student
		attendance1 = (attendance*100/45);
		return(attendance1);
	}
	
	public String getName(){  //method to return name
		return(Name);
	}
	
	public float getTotalAttendance() {  //method to return total average attendance
		totalAttendance=(totalAttendance*100/(45*60));
		return(totalAttendance);
	}
	
}
