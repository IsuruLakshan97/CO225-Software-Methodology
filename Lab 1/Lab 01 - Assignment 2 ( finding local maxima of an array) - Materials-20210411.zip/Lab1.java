class Lab1 { 

    public static void showMaxima(int [] array) { 
	// implement 
    }

    public static void main(String [] args) { 
	int [] array = {0, 1, 2, 1, 0, -1, 2, 3, 5, 6, 7, 4, 3, 4, 6, 5, 4};
	showMaxima(array);
    }
}
