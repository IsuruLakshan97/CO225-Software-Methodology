import java.io.*;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
/*
* Read given file in directory

*/

public class Less extends GenericCommand {

	public void handleCommand(String [] args) { 
		String name = args[1]; 		//Get file name 
		if(!args[0].equals("less")){	//When the code is wrong
			someThingWrong();
		}
                
		try { 
	    		BufferedReader buffer_read = new BufferedReader(new FileReader(name));//Read the file
	    		String content = null; 
	    		while( (content = buffer_read.readLine()) != null) { 
				System.out.println(content);			//Print the file content
	    		}
	    		buffer_read.close();

		}catch (FileNotFoundException x) { 
	    		System.out.println("File is not here");		//If the file not there
		} catch (IOException x) { 
	    		System.out.println(x);
		} 
	}

}
