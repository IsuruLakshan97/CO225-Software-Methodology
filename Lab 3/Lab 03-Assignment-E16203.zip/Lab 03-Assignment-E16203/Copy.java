import java.io.*;
import java.util.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class Copy extends GenericCommand {

	public void handleCommand(String [] args) { 
		
		try {
			if(!args[0].equals("copy")){
				someThingWrong();
			}

			File input= new File(args[1]); 		//file input 
			File output=new File(args[2]); 		//file output
			
			InputStream input_stream = new FileInputStream(input);
			OutputStream output_stream = new FileOutputStream(output);
			
			 
			byte[] buffer= new byte[256];
			int length_file;
			
			while( (length_file= input_stream.read(buffer)) != -1 ){
				output_stream.write(buffer,0,length_file);  		//copying to the output file 
			}
			
			input_stream.close();
			output_stream.close();
			
			System.out.println("File Copying is over");  //when it is over
		} catch (IOException e) {
			System.out.println("File is not here");
			return;
		}
	}

}
