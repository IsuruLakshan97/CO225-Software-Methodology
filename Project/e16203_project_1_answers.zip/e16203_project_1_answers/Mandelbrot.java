import java.awt.*; 
import javax.swing.*;
import java.awt.geom.Line2D; 
import java.awt.event.*;
import java.util.Random;
import java.lang.Math;


public class Mandelbrot extends Fractals{ 
  
    public void start(String [] args){

      if(!args[0].equals("Mandelbrot")){
        System.out.println("Something wrong");
        System.exit(-1);
      }
      
      //change default values if user insist
      if(args.length==5){
        x_min=Double.parseDouble(args[1]);
        x_max=Double.parseDouble(args[2]);
        y_min=Double.parseDouble(args[3]);
        y_max=Double.parseDouble(args[4]);
      }

      if(args.length==6){
        x_min=Double.parseDouble(args[1]);
        x_max=Double.parseDouble(args[2]);
        y_min=Double.parseDouble(args[3]);
        y_max=Double.parseDouble(args[4]);
        maxIteration=Integer.parseInt(args[5]); 
      }
      //calculating multiplication factor
       double x_mulfac = Math.abs(x_max-x_min)/X_WIDTH;
       double y_mulfac = Math.abs(y_max-y_min)/Y_WIDTH; 
    }


      public void paintComponent(Graphics g) { // override 
      super.paintComponent(g); 
      Graphics2D f = (Graphics2D) g; 
        for(int i=0; i<X_WIDTH; i++)
          for(int j=0; j<Y_WIDTH; j++){

            //mapping pixel value to the complex plane and obtain corresponding real and imag values 
            double x = x_min+i*x_mulfac;
            double y = y_min+j*y_mulfac;

            //initiate comlplex z wih 0,0
            Complex z = new Complex(0,0);

            //assigning obtained values to a new complex number
            Complex c = new Complex(x,y);
            double z_abs=0;    //to keep absolute value
            int iteration = 0;

            while(iteration<maxIteration){
              z = Complex.complexSqr(z); //get squre of complex
              z_abs = Complex.complexAbs(z);   //get abs of z^2

              if(z_abs>4) {
                 break;
                 }       //check for fractal

              z = Complex.complexSum(z,c);  //add z and c
              iteration++;
            }

           //check wether fractal is in Julia set and print relevent point with relevent colour
          if(iteration<maxIteration){
            printPoint(f,Color.getHSBColor((float)iteration*20.0f/(float)maxIteration,1.0f,1.0f),i,j);
            }
            else
              printPoint(f,Color.BLACK,i,j);
        }    

      }
  }

