public class Quit extends Fractals{

	public void start(String [] args){

    	if(!args[0].equals("quit")){
    	System.out.println("Something wrong");
        System.exit(-1);
    	}

    	if(args.length != 1) { 
	    System.out.println("Usage: quit");
	    System.exit(0);
		}

		System.exit(0); 
	}

}