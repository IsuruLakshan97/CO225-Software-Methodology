import java.lang.Math;


public class Complex {   //making complex class for complex number calculations
	public double real;    
	public double imag;
	
	public Complex(double real, double imag) {   //constructer setting real and imaginary parts of complex number
		this.real = real;
		this.imag = imag;
	}
	public double getReal() {    //get real
		return real;
	}
	
	public double getImag() {    //get imaginary
		return imag;
	}
	
    public static Complex complexSum(Complex A, Complex B) {   //method to get summation of two complex numbers
     double C = A.getReal()+ B.getReal();
     double D = A.getImag()+B.getImag();
     Complex P = new Complex(C,D);
     return P;
    }
    
    public static double complexAbs(Complex A) {             //method to absolute value of a complex number
    	double C = A.getReal()*A.getReal()+A.getImag()*A.getImag();
    	double D = Math.sqrt(C);
    	return D;
    }

     public static Complex complexSqr(Complex A) {          //method to get squared of a complex number
    	double C = A.getReal()*A.getReal()-(A.getImag()*A.getImag());
    	double D = 2*A.getReal()*A.getImag();
    	Complex P = new Complex(C,D);
    	return P;
    }
}
