import java.io.*;
import java.util.*;
import java.awt.*; 
import javax.swing.*;
import java.awt.geom.Line2D; 
import java.awt.event.*;

public class Main{ 

	//here i will use a hashmap to retrieve the relevent fractal based on user input
	public static HashMap<String, Fractals> fractalList = new HashMap<String, Fractals>();

	//add values to Hashmap
	public static void Linking(){
		fractalList.clear();

		fractalList.put("Mandelbrot",new Mandelbrot());
		fractalList.put("Julia", new Julia());
		fractalList.put("quit",new Quit());
	}

    //convert user entered string in to a string array removing spaces in between
    public static String[] makeArgs(String inputString){
    	String [] args = inputString.split(" ");
    	return args;
    }


    //call the command by user
    public static void getFractalPlot(String[] args){
    	//if user entered nothing return
    	if(args.length==0)
    		return;

    	//new fractal object
    	Fractals object = fractalList.get(args[0]);

    	//if user entered incorrect fractal
    	if(object==null){
    		System.out.println("incorrect command");
    		return;
    	}

    	//calling start method in specific fractal to change default values, if theres any.
    	object.start(args);


    	JFrame frame = new JFrame("Fractals"); 
		frame.setContentPane(object);
		frame.setPreferredSize(new Dimension(object.X_WIDTH, object.Y_WIDTH)); 
		frame.setSize(object.X_WIDTH, object.Y_WIDTH); 
		frame.pack(); 
		frame.setVisible(true);

    }


	public static void main(String[] args) {
		String userInput="";
		Linking();
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter 'Mandelbrot' or 'Julia' to get respective Fractal plotted with default values");
		System.out.println("Usage: <Fractal name> <x_min> <x_max> <y_min> <y_max> <Max_Iterations>");
		System.out.println("Enter 'quit' to exit");


		while(true){
			System.out.print("fractal>>>>>>>>>>>>>>>");
		    userInput = scan.nextLine();
			String [] arguments=makeArgs(userInput);
			getFractalPlot(arguments);
		}
	}
	


}