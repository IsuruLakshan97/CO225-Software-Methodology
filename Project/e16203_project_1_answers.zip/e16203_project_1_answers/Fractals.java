import java.awt.*; 
import javax.swing.*;
import java.awt.geom.Line2D; 
import java.awt.event.*;
import java.util.Random;


public class Fractals extends JPanel { 

    //setting given values for the panel size  
    static int X_WIDTH = 800; 
    static int Y_WIDTH = 800;

    //default max and min values for the real and imag parts of the complex number
    double x_min = -1;
    double x_max = 1;
    double y_min = -1;
    double y_max = 1;

    //calculating multiplication factor for default values
    double x_mulfac = (x_max-x_min)/X_WIDTH;
    double y_mulfac = (y_max-y_min)/Y_WIDTH; 

    int maxIteration = 1000;    //default max iterations

   
    public void start(String [] args){     
        System.out.println("Input Error");
    }
	   

    public static void printPoint(Graphics2D frame, Color c, double x, double y) {   //printing the relevent pixel with a given colour

        frame.setColor(c); 
        frame.draw(new Line2D.Double(x, y, x, y)); 
        }

}
  

