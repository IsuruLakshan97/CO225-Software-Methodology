import java.awt.*; 
import javax.swing.*;
import java.awt.geom.Line2D; 
import java.awt.event.*;
import java.util.Random;
import java.lang.Math;


public class Julia extends Fractals { 

      
    static Complex c = new Complex(-0.4,0.6); //default complex number

     public void start(String [] args){

        if(!args[0].equals("Julia")){
        System.out.println("Something wrong");
        System.exit(-1);
        }

        //if there is one argument its for number of iterations
        if(args.length==2)
          maxIteration=Integer.parseInt(args[1]);

        //if there is 3 arguments its for the complex number and no of iterations
        if(args.length==4){
          double real=Double.parseDouble(args[1]);
          double imag=Double.parseDouble(args[2]);
          maxIteration=Integer.parseInt(args[3]);
          
          c = new Complex(real,imag); //modify default complex number to entered number
                                      

        }

     }	    

  	public void paintComponent(Graphics g) { // override 
		  super.paintComponent(g); 
		  Graphics2D f = (Graphics2D) g; 
  	  for(int i=0; i<X_WIDTH; i++)
  		  for(int j=0; j<Y_WIDTH; j++){

         //mapping pixel value to the complex plane and obtain corresponding real and imag values
  			 double x = x_min+i*x_mulfac;
  			 double y = y_min+j*y_mulfac;
  
        //assigning obtained values to a new complex number
  			 Complex z = new Complex(x,y);
  			 double z_abs = 0; //for keep absolute value of z^2
         int iteration = 0;

  			 while(iteration<maxIteration){
  				  z = Complex.complexSqr(z); //get square of z
  				  z_abs = Complex.complexAbs(z);     //get absolute value of z^2

  				  if(z_abs>4) break;           
  
  				  z = Complex.complexSum(z,Julia.c); //add z^2 and c
            iteration++;
  			 }

	        //check wether fractal is in Julia set and print relevent point with relevent colour
	 			  if(iteration<maxIteration){
              printPoint(f,Color.getHSBColor((float)iteration*20.0f/(float)maxIteration,1.0f,1.0f),i,j);
            }
          else{
              printPoint(f,Color.BLACK,i,j);
          }
  		}

    }
 }   



