public class Person {
	private String name;
	private double height;
	private double weight;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	
	public double calBMI() {
		double c = Math.round( weight/(height*height) *100.0)/100.0;
		return c;
	}
	@Override
	public String toString() {
		if (calBMI()<18) {
		return "Person [name=" + name + ", height=" + height + ", weight=" + weight + ", calBMI()=" + calBMI() + ", Status:You are unhealthy" +  "]";
		}
		else if (calBMI()>=23) {
			return "Person [name=" + name + ", height=" + height + ", weight=" + weight + ", calBMI()=" + calBMI() + ", Status:You are unhealthy" +  "]";
			}
		else {
			return "Person [name=" + name + ", height=" + height + ", weight=" + weight + ", calBMI()=" + calBMI() + ", Status:You are healthy" +  "]";
		}
	}
	
}
