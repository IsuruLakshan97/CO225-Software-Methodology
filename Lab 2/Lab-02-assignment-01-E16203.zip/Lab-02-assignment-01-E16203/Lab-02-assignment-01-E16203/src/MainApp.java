import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;

public class MainApp {

	public static void main(String[] args) throws IOException {
	
		BufferedReader br;   //read from file
		
		ArrayList<Person> personList = new ArrayList<Person>();  //creating an arraylist of person objects
		
		
		String[] lineArray = new String[3]; 
		String text_line = null;
		
		try {
			br = Files.newBufferedReader(Paths.get("input.txt"));
			
			text_line = br.readLine();
			
			while(text_line !=null) {
				
				
				lineArray = text_line.split(",");   
				
				Person person = new Person();     //create new Person type person variable 
				person.setName(lineArray[0].toString());    //set readed values to appropriate attributes
				person.setHeight(Double.parseDouble(lineArray[1]));
				person.setWeight(Double.parseDouble(lineArray[2]));

				personList.add(person);      //added that person class to arraylist 
				text_line = br.readLine();
				
			}
			br.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		for (Iterator<Person> iterator = personList.iterator(); iterator.hasNext();) {  //passing elements in arraylist element by element to 'tostring' method 
			Person person2 = (Person) iterator.next();
			System.out.println(person2.toString());
			
		}
	

		
	}

}
