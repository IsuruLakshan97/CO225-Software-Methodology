import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;  // Import the Scanner class

public class Main {
	public static void main(String[] args) throws IOException {
        BufferedReader br;                                            
		
		ArrayList<Person> personList = new ArrayList<Person>();   //crate an arraylist to hold Person class objects
		
		
		String[] lineArray = new String[3]; 
		String text_line = null;
		
		try {
			br = Files.newBufferedReader(Paths.get("contacts.txt"));  // file read
			
			text_line = br.readLine();
			
			while(text_line !=null) {
				
				
				lineArray = text_line.split(",");
				
				Person person = new Person();        // creating new Person type person variable and setting attributes using readed file
				person.setFirstName(lineArray[0]);
				person.setLastName(lineArray[1]);
				person.setTelNumber(lineArray[2]);

				personList.add(person);       //add each class to arraylist
				text_line = br.readLine();
				
			}
			br.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		while (true) {   // while loop to go until user input exit
		    Scanner myObj = new Scanner(System.in);   //scanning input
            String input = myObj.nextLine();         


		if (input.equals("exit")){    // to break out of the loop
			break;
		}
		


		else{

		if(input.charAt(0)=='F') {      //if first character is 'F'.....
		int i = 0;
		String name = input.substring(2,input.length());     //removing ':' character from input string and get the rest from input string
		for (Iterator<Person> iterator = personList.iterator(); iterator.hasNext();) {   //accessing element by element in arraylist checking a match between input string and first name attribute of classes
			Person person2 = (Person) iterator.next();
			if(name.equals(person2.getFirstName())) {     // if found a match, run 'getTelNumber' method in that particular class
			    System.out.printf("%s %s - %s\n",person2.getFirstName(),person2.getLastName(),person2.getTelNumber());
			    i++;
			}
		}
		if(i==0){                       //if no such person found
			System.out.println("No such person");
		}	
		
		}
		
		else if(input.charAt(0)=='L') {   //if first character is 'L'.....
		int i = 0;
			String name = input.substring(2,input.length());   //removing ':' character from input string and get the rest from input string
			for (Iterator<Person> iterator = personList.iterator(); iterator.hasNext();) {   //accessing element by element in arraylist checking a match between input string and last name attribute of classes
				Person person2 = (Person) iterator.next();
				if(name.equals(person2.getLastName())) {        // if found a match, run 'getTelNumber' method in that particular class
				System.out.printf("%s %s - %s\n",person2.getFirstName(),person2.getLastName(),person2.getTelNumber());
				i++;
				}
			}	
		if(i==0){                                       //if no such person were found
			System.out.println("No such person");
		}	
		}
        }
        



	    }
  }

}  
