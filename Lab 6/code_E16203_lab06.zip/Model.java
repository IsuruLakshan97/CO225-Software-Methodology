
class Model {

    int turn;
    char[][] T_Matrix = new char[3][3];
    char Player;
    String button;
    int WinSequence;
    int Winner;

    public int getWinSequence() {      //method to sense game over and to get winning pattern
        if (button == "button1") {
            if (T_Matrix[0][1] == Player && T_Matrix[0][2] == Player) {
                WinSequence = 1;
            } else if (T_Matrix[1][0] == Player && T_Matrix[2][0] == Player) {
                WinSequence = 4;
            } else if (T_Matrix[1][1] == Player && T_Matrix[2][2] == Player) {
                WinSequence = 7;
            }
        } else if (button == "button2") {
            if (T_Matrix[1][1] == Player && T_Matrix[2][1] == Player) {
                WinSequence = 2;
            } else if (T_Matrix[0][0] == Player && T_Matrix[0][2] == Player) {
                WinSequence = 4;
            }
        } else if (button == "button3") {
            if (T_Matrix[1][2] == Player && T_Matrix[2][2] == Player) {
                WinSequence = 3;
            } else if (T_Matrix[0][0] == Player && T_Matrix[0][1] == Player) {
                WinSequence = 4;
            } else if (T_Matrix[1][1] == Player && T_Matrix[2][0] == Player) {
                WinSequence = 8;
            }
        } else if (button == "button4") {
            if (T_Matrix[0][0] == Player && T_Matrix[0][2] == Player) {
                WinSequence = 1;
            } else if (T_Matrix[1][1] == Player && T_Matrix[1][2] == Player) {
                WinSequence = 5;
            }
        } else if (button == "button5") {
            if (T_Matrix[0][1] == Player && T_Matrix[2][1] == Player) {
                WinSequence = 2;
            } else if (T_Matrix[1][0] == Player && T_Matrix[1][2] == Player) {
                WinSequence = 5;
            } else if (T_Matrix[0][0] == Player && T_Matrix[2][2] == Player) {
                WinSequence = 7;
            } else if (T_Matrix[0][2] == Player && T_Matrix[2][0] == Player) {
                WinSequence = 8;
            }
        } else if (button == "button6") {
            if (T_Matrix[0][2] == Player && T_Matrix[2][2] == Player) {
                WinSequence = 3;
            } else if (T_Matrix[1][0] == Player && T_Matrix[1][1] == Player) {
                WinSequence = 5;
            }
        } else if (button == "button7") {
            if (T_Matrix[0][0] == Player && T_Matrix[1][0] == Player) {
                WinSequence = 1;
            } else if (T_Matrix[2][1] == Player && T_Matrix[2][2] == Player) {
                WinSequence = 6;
            } else if (T_Matrix[0][2] == Player && T_Matrix[1][1] == Player) {
                WinSequence = 8;
            }
        } else if (button == "button8") {
            if (T_Matrix[0][1] == Player && T_Matrix[1][1] == Player) {
                WinSequence = 2;
            } else if (T_Matrix[2][0] == Player && T_Matrix[2][2] == Player) {
                WinSequence = 6;
            }
        } else if (button == "button9") {
            if (T_Matrix[0][2] == Player && T_Matrix[1][2] == Player) {
                WinSequence = 3;
            } else if (T_Matrix[2][0] == Player && T_Matrix[2][1] == Player) {
                WinSequence = 6;
            } else if (T_Matrix[0][0] == Player && T_Matrix[1][1] == Player) {
                WinSequence = 7;
            }
        }

        return WinSequence;
    }


    public int getWinner(){         //to return the winning player when a game over is sensed
        if (WinSequence != 0) {
            if (Player == '1') {
                Winner = 1;
            } else {
                Winner = 2;
            }
        } else if (turn == 9) {
            Winner = 3;
        }

        return Winner;
    }

}
