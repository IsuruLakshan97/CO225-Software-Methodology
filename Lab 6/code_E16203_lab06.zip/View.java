import javax.swing.*;
import java.awt.*;
import java.util.EventObject;
	
public class View extends JFrame{
	static JButton button1;
	static JButton button2;
	static JButton button3;
	static JButton button4;
	static JButton button5;
	static JButton button6;
	static JButton button7;
	static JButton button8;
	static JButton button9;	
	static JPanel panel;
	static JFrame frame;

	View(){

	 	/*setting up a new frame and panel to show up the grid */
	 	frame = new JFrame("TIC-TAC-TOE");                    
		frame.setPreferredSize(new Dimension(500, 500)); 
		frame.pack(); 
		frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel=new JPanel(new GridLayout(3,3));
		panel.setSize(500, 500);


		button1 = new JButton();
		button2 = new JButton();
		button3 = new JButton();
		button4 = new JButton();
		button5 = new JButton();
		button6 = new JButton();
		button7 = new JButton();
		button8 = new JButton();
		button9 = new JButton();
			
                
		button1.setName("button1");
		button2.setName("button2");
		button3.setName("button3");
		button4.setName("button4");
		button5.setName("button5");
		button6.setName("button6");
		button7.setName("button7");
		button8.setName("button8");
		button9.setName("button9");
		
		/*adding buttons to the panal*/
		panel.add(button1);
		panel.add(button2);
		panel.add(button3);
		panel.add(button4);
		panel.add(button5);
		panel.add(button6);
		panel.add(button7);
		panel.add(button8);
		panel.add(button9);
		
		frame.setVisible(true);
		panel.setVisible(true);
		frame.add(panel);
	}
	
	static void gridclose() {
		frame.dispose();
	}
	
}
