
import javax.swing.*;
import java.awt.*;
import java.util.EventObject;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;

public class Controller extends View {
    
    static View view;
    static Model model;
    static int turn = 1;
    
    public static void main(String args[]) {
        start();                                               
    }

    public static void start(){
        view = new View();
        model = new Model();
        
        button1.addActionListener(new clickSense());
        button2.addActionListener(new clickSense());
        button3.addActionListener(new clickSense());
        button4.addActionListener(new clickSense());
        button5.addActionListener(new clickSense());
        button6.addActionListener(new clickSense());
        button7.addActionListener(new clickSense());
        button8.addActionListener(new clickSense());
        button9.addActionListener(new clickSense());
    }
    
    static class clickSense implements ActionListener {
        
        public void actionPerformed(ActionEvent e) {       //execute at every button press
            JButton Btn = (JButton) e.getSource();
            char Player;
            
            if (model.turn % 2 == 0) {                      //getting who is the current player 
                Player = '1';
            } else {
                Player = '2';
            }
            Btn.setText(Character.toString(Player));        //button  text set
            Btn.setFont(new Font("Arial", Font.PLAIN, 40));    //button font & size set                                         
            

            model.Player = Player;
            model.turn = turn;
            model.button = Btn.getName();
            
            /* button colour set according to player */
            if (Player == '1'){
               Btn.setBackground(Color.green);
            }
            else{
              Btn.setBackground(Color.yellow);
            }


            /* to sence the winner here i input player ID to a matrix based on there input button */
            if (Btn.getName() == "button1") {
                model.T_Matrix[0][0] = Player;
            } else if (Btn.getName() == "button2") {
                model.T_Matrix[0][1] = Player;
            } else if (Btn.getName() == "button3") {
                model.T_Matrix[0][2] = Player;
            } else if (Btn.getName() == "button4") {
                model.T_Matrix[1][0] = Player;
            } else if (Btn.getName() == "button5") {
                model.T_Matrix[1][1] = Player;
            } else if (Btn.getName() == "button6") {
                model.T_Matrix[1][2] = Player;
            } else if (Btn.getName() == "button7") {
                model.T_Matrix[2][0] = Player;
            } else if (Btn.getName() == "button8") {
                model.T_Matrix[2][1] = Player;
            } else if (Btn.getName() == "button9") {
                model.T_Matrix[2][2] = Player;
            }
            
            
            
            /*getting the win pattern When game is over*/
            int A = model.getWinSequence();                    
            
            if (A == 1) {
                button1.setBackground(Color.red);
                button4.setBackground(Color.red);
                button7.setBackground(Color.red);
                freezeButtons();
            } else if (A == 2) {
                button2.setBackground(Color.red);
                button5.setBackground(Color.red);
                button8.setBackground(Color.red);
                freezeButtons();
            } else if (A == 3) {
                button3.setBackground(Color.red);
                button6.setBackground(Color.red);
                button9.setBackground(Color.red);
                freezeButtons();
            } else if (A == 4) {
                button1.setBackground(Color.red);
                button2.setBackground(Color.red);
                button3.setBackground(Color.red);
                freezeButtons();
            } else if (A == 5) {
                button4.setBackground(Color.red);
                button5.setBackground(Color.red);
                button6.setBackground(Color.red);
                freezeButtons();
            } else if (A == 6) {
                button7.setBackground(Color.red);
                button8.setBackground(Color.red);
                button9.setBackground(Color.red);
                freezeButtons();
            } else if (A == 7) {
                button1.setBackground(Color.red);
                button5.setBackground(Color.red);
                button9.setBackground(Color.red);
                freezeButtons();
            } else if (A == 8) {
                button3.setBackground(Color.red);
                button5.setBackground(Color.red);
                button7.setBackground(Color.red);
                freezeButtons();
            }
            
            if (A > 0) {           //if the match is a draw
                freezeButtons();
            }
            
            /* Winner Display in seperate window */
            int Winner = model.getWinner();
            if (Winner == 1) {
                 int a=JOptionPane.showConfirmDialog(null,"Congradulations!!\nPlayer '1' Wins\n"+"Do you want to try again?");     //message display
                        if(a==JOptionPane.YES_OPTION){
                            gridclose(); 
                            turn = 0; 
                            start();                         //start again when user prompts
                        }
                        else if (a==JOptionPane.NO_OPTION){
                            System.exit(0);
                        } 
            } else if (Winner == 2) {
                int b=JOptionPane.showConfirmDialog(null,"Congradulations!!\nPlayer '2' Wins\n"+"Do you want to try again?");  
                        if(b==JOptionPane.YES_OPTION){ 
                            gridclose(); 
                            turn = 0;
                            start();  
                        }
                        else if (b==JOptionPane.NO_OPTION){
                            System.exit(0);
                        }
            } else if (Winner == 3) {
                int c=JOptionPane.showConfirmDialog(null,"Well Played!!\nMatch Drawed\n"+"Do you want to try again?");  
                        if(c==JOptionPane.YES_OPTION){ 
                            gridclose(); 
                            turn = 0;
                            start();  
                        }
                        else if (c==JOptionPane.NO_OPTION){
                            System.exit(0);
                        }
            }
            
            Btn.setEnabled(false);
            turn++;
        }
    }
    
    static void freezeButtons() {
        button1.setEnabled(false);
        button2.setEnabled(false);
        button3.setEnabled(false);
        button4.setEnabled(false);
        button5.setEnabled(false);
        button6.setEnabled(false);
        button7.setEnabled(false);
        button8.setEnabled(false);
        button9.setEnabled(false);
        
    }

}
